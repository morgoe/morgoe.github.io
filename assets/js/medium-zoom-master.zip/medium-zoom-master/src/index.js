const mediumZoom = require('./medium-zoom')
require('./medium-zoom.css')

module.exports = mediumZoom
